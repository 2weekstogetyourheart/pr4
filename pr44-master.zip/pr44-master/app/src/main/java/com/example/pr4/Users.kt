package com.example.pr4

data class Users(
    val name: String,
    val surname: String,
    val patronymic: String,
    val password: String,
    val birthday: String,
    val pol: String
)
