package com.example.pr4

import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity8 : AppCompatActivity() {

    private lateinit var nameEditText: EditText
    private lateinit var surnameEditText: EditText
    private lateinit var patronymicEditText: EditText
    private lateinit var birthdayEditText: EditText
    private lateinit var polEditText: EditText
    private lateinit var createButton: Button

    private var password: String = pass // Получите реальный пароль из другого окна

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main8)

        nameEditText = findViewById(R.id.name)
        surnameEditText = findViewById(R.id.name1)
        patronymicEditText = findViewById(R.id.name2)
        birthdayEditText = findViewById(R.id.name3)
        polEditText = findViewById(R.id.name4)
        createButton = findViewById(R.id.buttonCrete)

        // Устанавливаем слушатель изменения текста для каждого EditText поля
        val textWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                val allFieldsFilled = (
                        nameEditText.text.isNotEmpty() &&
                                surnameEditText.text.isNotEmpty() &&
                                patronymicEditText.text.isNotEmpty() &&
                                birthdayEditText.text.isNotEmpty() &&
                                polEditText.text.isNotEmpty()
                        )

                if (allFieldsFilled) {
                    createButton.isEnabled = true
                    createButton.setBackgroundColor(Color.parseColor("#1A6FEE"))
                    createButton.setTextColor(Color.WHITE)
                } else {
                    createButton.isEnabled = false
                    createButton.setBackgroundColor(Color.parseColor("#C9D4FB"))
                    createButton.setTextColor(Color.parseColor("#FFFFFF"))
                }
            }
        }

        nameEditText.addTextChangedListener(textWatcher)
        surnameEditText.addTextChangedListener(textWatcher)
        patronymicEditText.addTextChangedListener(textWatcher)
        birthdayEditText.addTextChangedListener(textWatcher)
        polEditText.addTextChangedListener(textWatcher)

        createButton.setOnClickListener {
            createUser()
        }
    }

    private fun createUser() {
        val name = nameEditText.text.toString()
        val surname = surnameEditText.text.toString()
        val patronymic = patronymicEditText.text.toString()
        val birthday = birthdayEditText.text.toString()
        val pol = polEditText.text.toString()

        val user = Users(name, surname, patronymic, password, birthday, pol)
        val db = DBhelp(this, null)
        db.addUser(user)
        Toast.makeText(this, "Пользователь $name добавлен", Toast.LENGTH_LONG).show()

        nameEditText.text.clear()
        surnameEditText.text.clear()
        patronymicEditText.text.clear()
        birthdayEditText.text.clear()
        polEditText.text.clear()
    }
}
