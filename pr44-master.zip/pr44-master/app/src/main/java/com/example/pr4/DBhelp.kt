package com.example.pr4

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBhelp(context: Context, factory: SQLiteDatabase.CursorFactory?) :
    SQLiteOpenHelper(context, "app", factory, 1) {

    override fun onCreate(db: SQLiteDatabase?) {
        val query = """
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                surname TEXT,
                patronymic TEXT,
                password TEXT,
                birthday TEXT,
                pol TEXT
            )
        """
        db?.execSQL(query)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS users")
        onCreate(db)
    }

    fun addUser(user: Users) {
        val values = ContentValues().apply {
            put("name", user.name)
            put("surname", user.surname)
            put("patronymic", user.patronymic)
            put("password", user.password)
            put("birthday", user.birthday)
            put("pol", user.pol)
        }

        val db = this.writableDatabase
        try {
            db.insert("users", null, values)
        } finally {
            db.close()
        }
    }
}
